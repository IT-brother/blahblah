@extends('layouts.master')
@section('title','Show detail')
@section('header')
    @if(session('status'))
        
    @endif
@endsection
@section('content')
    <div class="card">
        <div class="card-body row">
            <div class="col-xl-12 alert alert-success p-2">{{session('status')}}</div>
        </div>
    </div>
@endsection
@section("script")
<script>
     var baseUrl = '{{url("")}}';
    $(document).ready(function(){
       
    });
</script>
@endsection