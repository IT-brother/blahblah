@extends('layouts.master')
@section('title','Upload news')
@section('header')
    @if(session('status'))
        <div class="offset-lg-4 col-lg-4 alert alert-success p-2">{{session('status')}}</div>
    @endif
    @if(session('errors'))
    <div class="row col-xl-12 alert alert-success p-2 alert alert-warning">
       <ul> 
        @foreach($errors as $error)
            <li>{{$error}}</li> 
        @endforeach
        </ul>
    </div>
    @endif
@endsection
@section('content')
<form method="post" enctype="multipart/form-data">
    @csrf
    <div class="card">
        <div class="card-body">
            <div class="form-group">
                <label class="control-label" for="title">Title <b class="text-danger">*</b></label>
                <input type="text" class="form-control" name="title" id="title">
            </div>
            <div class="form-group row">
                <div class="col-lg-6">
                    <label class="control-label"  for="category_id">Category <b class="text-danger">*</b></label>
                    <select  class="form-control" name="category_id[]"  id="category_id" multiple>
                        <option value=""></option>
                        @if(count($categories) > 0)
                            @foreach($categories as $key=>$category)
                                <option value="{{$category->id}}">{{$category->name}}</option>
                            @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-6">
                    <label class="control-label" for="date">Date <b class="text-danger">*</b></label>
                    <input type="text" name="date" class="form-control" id="date">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label" for="content">Content <b class="text-danger">*</b></label>
                <textarea  name="content" id="content" class="summernote"></textarea>
            </div>
            <div class="form-group">
                <label class="control-label" for="movies">Movies (Optional)</label>
                <input type="file" class="form-control" name="movies[]" multiple id="movies">
            </div>
            <div class="form-group">
                <label class="control-label" for="photos">Photo (Optional)</label>
                <input type="file" class="form-control" name="photos[]" multiple id="photos">
            </div>
            <div class="form-group">
                <label class="control-label" for="files">File (Optional)</label>
                <input type="file" class="form-control" name="files[]" multiple id="files">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Submit</button>
            </div>
        </div>
    </div>
</form>
@endsection
@section("script")

<script>
    $(document).ready(function(){
        // $("#category_id").select2();
        var date = new Pikaday(
        {
            field: document.getElementById('date'),
            theme: 'triangle-theme'
        });
        $('.summernote').summernote({
            height: 200,
            tabsize: 2,
            toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'clear','strikethrough']],
                    // ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['height', ['height']],
                    //['table',['table']]
                ]  
        });
    });
</script>
@endsection