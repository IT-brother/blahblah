@extends('layouts.master')
@section('title','Edit news')
@section('header')
    @if(session('status'))
        <div class="offset-lg-4 col-lg-4 alert alert-success p-2">{{session('status')}}</div>
    @endif
    @if(session('errors'))
    <div class="row col-xl-12 alert alert-success p-2 alert alert-warning">
       <ul> 
        @foreach($errors as $error)
            <li>{{$error}}</li> 
        @endforeach
        </ul>
    </div>
    @endif
@endsection
@section('content')
<form method="post" enctype="multipart/form-data">
    @csrf
    <div class="card">
        <div class="card-body">
            
            <div class="form-group col-xl-12 row">
                <div class=" col-xl-12">
                    <label class="control-label" for="title">Title (ခေါင်းစဉ်)<b class="text-danger">*</b></label>
                    @if($information->user_id == Auth::user()->id)
                        @if($information->softDelete == null)
                            <span class="fa fa-times waves-effect waves-danger text-danger float-right information-delete" data-id="{{$information->id}}" style="cursor:pointer;"></span>
                        @else
                            <span class="fa fa-check waves-effect waves-danger text-success float-right information-cancel" data-id="{{$information->id}}" style="cursor:pointer;"></span>
                        @endif
                    @endif
                    <input type="text" value="{{$information->title}}" class="form-control" name="title" id="title">
                    
                </div>
                
            </div>
            @foreach($information->categories as $selectedCategory)
                @php $selectedArray[]=$selectedCategory->id; @endphp
            @endforeach
            <div class="form-group row">
                <div class="col-lg-6">
                    <label class="control-label"  for="category_id">Category (အမျိုးအစား)<b class="text-danger">*</b></label>
                    <select  class="form-control" name="category_id[]"  id="category_id" multiple>
                        <option value=""></option>
                        @if(count($categories) > 0)
                            @foreach($categories as $key=>$category)
                                @if(in_array($category->id,$selectedArray))
                                    <option value="{{$category->id}}" selected>{{$category->name}}</option>
                                @else
                                    <option value="{{$category->id}}">{{$category->name}}</option>
                                @endif
                            @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-6">
                    <label class="control-label" for="date">Date (ရက်စွဲ)<b class="text-danger">*</b></label>
                    <input type="text" value="{{$information->date}}" name="date" class="form-control" id="date">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label" for="content">Content (အချက်အလက်များ)<b class="text-danger">*</b></label>
                <textarea  name="content" id="content" class="summernote">
                    <?php echo html_entity_decode($information->content); ?>
                </textarea>
            </div>
            @if(count($information->files) > 0)
                <div class="col-xl-12 row mt-3">
                    <h4 class="col-12"><i class="fa  fa-paperclip"></i> Attachments</h4>
                    @foreach($information->files as $key=>$file)
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="{{url('/files/'.$file->name)}}" target="_blank"><b>{{$key + 1 }}</b>. {{$file->name}}</a>
                            @if($information->user_id == Auth::user()->id)
                                @if($file->softDelete == null)
                                    <span class="text-danger fa fa-times file-delete" data-id="{{$file->id}}" style="cursor:pointer;margin-left:5px;"></span>
                                @else
                                    <span class="text-success fa fa-check file-cancel" data-id="{{$file->id}}" style="cursor:pointer;margin-left:5px;"></span>
                                @endif
                            @endif
                        </div>
                    @endforeach
                </div>
            @endif
            @if(count($information->photos) > 0)
               <div class="col-xl-12 mt-2 row">
                    <h4 class="col-12"><i class="fa  fa-image"></i> Photo</h4>
                    @foreach($information->photos as $key=>$photo)
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="{{url('/photo/'.$photo->name)}}" target="_blank"><b>{{$key + 1 }}</b>. {{$photo->name}}</a>
                            @if($information->user_id == Auth::user()->id)
                                @if($photo->softDelete == null)
                                    <span class="text-danger fa fa-times photo-delete" data-id="{{$photo->id}}" style="cursor:pointer;margin-left:5px;"></span>
                                @else
                                    <span class="text-success fa fa-check photo-cancel" data-id="{{$photo->id}}" style="cursor:pointer;margin-left:5px;"></span>
                                @endif
                            @endif
                        </div>
                    @endforeach
                </div>
            @endif
            @if(count($information->movies) > 0)
                <div class="col-xl-12 mt-2 row">
                    <h4 class="col-12"><i class="fa fa-video"></i> Movies</h4> 
                    @foreach($information->movies as $key=>$movie)
                    <div class="col-md-6 col-lg-4 p-2"> 
                        <a href="{{url('../resources/views/download.php?id='.$movie->name)}}"  data-id="{{$movie->name}}">{{$movie->name}}</a>
                        @if($information->user_id == Auth::user()->id)
                            @if($movie->softDelete == null)
                                <span class="text-danger fa fa-times movie-delete"  data-id="{{$movie->id}}" style="cursor:pointer;margin-left:5px;"></span>
                            @else
                                <span class="text-success fa fa-check movie-cancel" data-id="{{$movie->id}}" style="cursor:pointer;margin-left:5px;"></span>
                            @endif
                        @endif
                    </div>
                    @endforeach     
                </div><!-- col-xl-12 -->
            @endif
            <div class="form-group">
                <label class="control-label" for="movies">Movies (Optional)</label>
                <input type="file" class="form-control" name="movies[]" multiple id="movies">
            </div>
            <div class="form-group">
                <label class="control-label" for="photos">Photo (Optional)</label>
                <input type="file" class="form-control" name="photos[]" multiple id="photos">
            </div>
            <div class="form-group">
                <label class="control-label" for="files">File (Optional)</label>
                <input type="file" class="form-control" name="files[]" multiple id="files">
            </div>
            <div class="form-group">
                <label class="control-label" for="published">Publish or Unpublish (ထုတ်ဝေမည် (သို့) မထုတ်ဝေ)</label>
                <select  class="form-control" name="published" id="published">
                    @if($information->published == 1)
                        <option value="1" selected>Published</option>
                        <option value="0">Unpublished</option>
                    @else
                        <option value="1">Published</option>
                        <option value="0" selected>Unpublished</option>
                    @endif
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Update</button>
            </div>
            
        </div><!--- card-body --->
    </div>
</form>
@endsection
@section("script")
<script>
     var baseUrl = '{{url("")}}';
    $(document).ready(function(){
        $("#category_id").select2();
        var date = new Pikaday(
        {
            field: document.getElementById('date'),
            theme: 'triangle-theme'
        });
        $('.summernote').summernote({
            height: 200,
            tabsize: 2,
            toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'clear','strikethrough']],
                    // ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['height', ['height']],
                    //['table',['table']]
                ]  
        });

        $(document).on("click",".information-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/softDelete',
                    type: "GET",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".information-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/softDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".file-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/fileSoftDelete',
                    type: "GET",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".file-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/fileSoftDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".photo-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/photoSoftDelete',
                    type: "GET",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".photo-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/photoSoftDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".movie-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/movieSoftDelete',
                    type: "GET",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".movie-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/movieSoftDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
    });
</script>
@endsection