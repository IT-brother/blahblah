@extends('layouts.master')
@section('title','News list')
@section('header')
    <!--div class="col-7 align-self-center">
        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">News List</h4>
        <div class="d-flex align-items-center">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb m-0 p-0">
                    <li class="breadcrumb-item"><a href="index.html" class="text-muted">Apps</a></li>
                    <li class="breadcrumb-item text-muted active" aria-current="page">News List</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="col-5 align-self-center">
        <div class="customize-input float-right">
            <button class=" custom-select-set form-control bg-white border-0 custom-shadow custom-radius">
                CREATE NEW <i class="fa fa-plus text-success"></i>
            </button>
        </div>
    </div-->
@endsection
@section("content")
<?php
      use App\Http\Controllers\InformationController;
  ?>
<div class="container-fluid">
  <h4 class="text-muted">ဖျက်ရန် ပေးပို့ထားသောအချက်အလက်များ</h4>
  <ul class="nav nav-tabs">
    <li class="active p-1"><i class="fa fa-bell text-danger"></i><sup class="text-danger font-weight-bold">{{count($informations)}}</sup> <a data-toggle="tab" href="#home">သတင်းအားဖျက်ရန်</a> |</li>
    <li class="p-1"><i class="fa fa-bell text-danger"></i><sup class="text-danger font-weight-bold">{{count($files)}}</sup> <a data-toggle="tab" href="#menu1"> ဖိုင်ဖျက်ရန်</a> |</li>
    <li class="p-1"><i class="fa fa-bell text-danger"></i><sup class="text-danger font-weight-bold">{{count($photos)}}</sup> <a data-toggle="tab" href="#menu2"> ပုံဖျက်ရန်</a> |</li>
    <li class="p-1"><i class="fa fa-bell text-danger"></i><sup class="text-danger font-weight-bold">{{count($videos)}}</sup> <a data-toggle="tab" href="#menu3"> ဗီဒီယိုဖျက်ရန်</a></li>
  </ul>
  <div class="tab-content">
    <div id="home" class="tab-pane fade  active">
      <h3>ဖျက်ရန်ပေးပို့ထားသော သတင်းများ</h3>
      <table id="zero_config" class="table table-striped table-bordered">
          <thead>
              <tr>
                  <th>#</th>
                  <th style="width:30%;max-width:30%;">Title</th>
                  <th>Category</th>
                  <th style="min-width:60px;max-width:60px;">Date</th>
                  <th style="width:120px;max-width:120px;font-weight:bold;">Moderator</th>
                  <th style="min-width:60px;max-width:60px;">Published</th>
              </tr>
          </thead>
            <tbody>
            @if(count($informations) > 0)
                @foreach($informations as $key=>$information)
                    @if($information->published == 1)
                        @php $published ="published"; @endphp
                    @else
                        @php $published = "unpublished"; @endphp
                    @endif
                    <tr>
                        <td>{{$key + 1}}</td>
                        <td><a href="{{url('/admin/admin-news/'.$information->id)}}" style="color:#0099FF;text-decoration:underline;">{{$information->title}}</a></td>
                        <td>
                            <?php echo InformationController::category_convert($information->id); ?>
                        </td>
                        <td>{{date('d-m-Y',strtotime($information->date))}}</td>
                        <td>
                            <?php echo InformationController::moderator($information->user_id); ?>
                        </td>
                        <td>{{$published}}</td>
                    </tr>
                @endforeach
            @else
                <tr>
                    <td colspan="6" style="text-align:center">There is no news...</td>
                </tr>
            @endif
            </tbody>
        </table>
    </div>
    <div id="menu1" class="tab-pane fade">
      <h3>ဖျက်ရန်ပေးပို့ထားသော ဖိုင်များ</h3>
      <table class="table table-striped table-bordered">
          <thead>
              <tr>
                  <th>#</th>
                  <th style="width:30%;max-width:30%;">Title</th>
                  <th>Category</th>
                  <th style="min-width:60px;max-width:60px;">Date</th>
                  <th style="width:120px;max-width:120px;font-weight:bold;">Moderator</th>
                  <th style="min-width:60px;max-width:60px;">Published</th>
                  <th>File</th>
              </tr>
          </thead>
            <tbody>
            @if(count($files) > 0)
                    @foreach($files as $key=>$file)
                    @if($file->informations->published == 1)
                        @php $published ="published"; @endphp
                    @else
                        @php $published = "unpublished"; @endphp
                    @endif
                    <tr>
                        <td>{{$key + 1}}</td>
                        <td><a href="{{url('/admin/admin-news/'.$file->informations->id)}}" style="color:#0099FF;text-decoration:underline;">{{$file->informations->title}}</a></td>
                        <td>
                            <?php echo InformationController::category_convert($file->informations->id); ?>
                        </td>
                        <td>{{date('d-m-Y',strtotime($file->informations->date))}}</td>
                        <td>
                            <?php echo InformationController::moderator($file->informations->user_id); ?>
                        </td>
                        <td>{{$published}}</td>
                        <td>{{$file->name}}</td>
                    </tr>
                    @endforeach
                @else
                    <tr>
                        <td colspan="7" style="text-align:center">There is no news...</td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>
    <div id="menu2" class="tab-pane fade">
      <h3>ဖျက်ရန်ပေးပို့ထားသော ပုံများ</h3>
      <table class="table table-striped table-bordered">
          <thead>
              <tr>
                  <th>#</th>
                  <th style="width:30%;max-width:30%;">Title</th>
                  <th>Category</th>
                  <th style="min-width:60px;max-width:60px;">Date</th>
                  <th style="width:120px;max-width:120px;font-weight:bold;">Moderator</th>
                  <th style="min-width:60px;max-width:60px;">Published</th>
                  <th>Photo</th>
              </tr>
          </thead>
            <tbody>
            @if(count($photos) > 0)
                    @foreach($photos as $key=>$photo)
                    @if($photo->informations->published == 1)
                        @php $published ="published"; @endphp
                    @else
                        @php $published = "unpublished"; @endphp
                    @endif
                    <tr>
                        <td>{{$key + 1}}</td>
                        <td><a href="{{url('/admin/admin-news/'.$photo->informations->id)}}" style="color:#0099FF;text-decoration:underline;">{{$photo->informations->title}}</a></td>
                        <td>
                            <?php echo InformationController::category_convert($photo->informations->id); ?>
                        </td>
                        <td>{{date('d-m-Y',strtotime($photo->informations->date))}}</td>
                        <td>
                            <?php echo InformationController::moderator($photo->informations->user_id); ?>
                        </td>
                        <td>{{$published}}</td>
                        <td>{{$photo->name}}</td>
                    </tr>
                    @endforeach
                @else
                    <tr>
                        <td colspan="7" style="text-align:center">There is no news...</td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>
    <div id="menu3" class="tab-pane fade">
      <h3>ဖျက်ရန်ပေးပို့ထားသော ဗီဒီယိုဖိုင်များ</h3>
      <table class="table table-striped table-bordered">
          <thead>
              <tr>
                  <th>#</th>
                  <th style="width:30%;max-width:30%;">Title</th>
                  <th>Category</th>
                  <th style="min-width:60px;max-width:60px;">Date</th>
                  <th style="width:120px;max-width:120px;font-weight:bold;">Moderator</th>
                  <th style="min-width:60px;max-width:60px;">Published</th>
                  <th>Video</th>
              </tr>
          </thead>
            <tbody>
            @if(count($videos) > 0)
                    @foreach($videos as $key=>$video)
                    @if($video->informations->published == 1)
                        @php $published ="published"; @endphp
                    @else
                        @php $published = "unpublished"; @endphp
                    @endif
                    <tr>
                        <td>{{$key + 1}}</td>
                        <td><a href="{{url('/admin/admin-news/'.$video->informations->id)}}" style="color:#0099FF;text-decoration:underline;">{{$video->informations->title}}</a></td>
                        <td>
                            <?php echo InformationController::category_convert($video->informations->id); ?>
                        </td>
                        <td>{{date('d-m-Y',strtotime($video->informations->date))}}</td>
                        <td>
                            <?php echo InformationController::moderator($video->informations->user_id); ?>
                        </td>
                        <td>{{$published}}</td>
                        <td>{{$video->name}}</td>
                    </tr>
                    @endforeach
                @else
                    <tr>
                        <td colspan="7" style="text-align:center">There is no news...</td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>
  </div>
</div>
@endsection
@section("script")
  
@endsection
