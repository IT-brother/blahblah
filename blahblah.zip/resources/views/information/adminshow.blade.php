@extends('layouts.master')
@section('title','Show detail')
@section('header')
    @if(session('status'))
        <div class="offset-lg-4 col-lg-4 alert alert-success p-2">{{session('status')}}</div>
    @endif
@endsection
<style>
    <style>
    /* Make the image fully responsive */
    .carousel-inner img {
        width: 100%;
        height: 100%;
    }
  </style>
</style>
@section('content')
    <div class="card">
        <div class="card-body row">
            <a href="{{url()->previous()}}" class="btn btn-info btn-floating btn-md sunny-morning-gradient waves-effect waves-light">
                <i class="fa fa-arrow-left"></i> Back
            </a>
            <div class="col-xl-12">
                <h3>
                    {{$information->title}}
                </h3>
                <p style="font-size:13px;">
                    <span class='badge badge-default border' style='font-size:13px;'>
                        <i class="fa fa-calendar text-success"></i>
                        {{date('d-m-Y',strtotime($information->date))}}
                    </span>
                    @foreach($information->categories as $key=>$category)
                        <span class='badge badge-default border' style='font-size:13px;'><i class="fa fa-tag text-info"></i> {{$category->name}}</span>
                    @endforeach
                    @if($information->published == 1)
                        <span class='badge badge-default border' style='font-size:13px;'><i class="fa fa-circle text-success"></i> Published</span>    
                    @else
                        <span class='badge badge-default border' style='font-size:13px;'><i class="fa fa-tag text-danger"></i> Unpublished</span>    
                    @endif
                    <span class='badge badge-default border' style='font-size:13px;'>
                        <i class="fa fa-user text-default"></i>
                        {{$information->users->name}}
                    </span>
                    @if(Auth::user()->role_id == 1)
                        @if($information->softDelete == 1)
                            <span class="fa fa-times waves-effect text-danger float-right information-delete" data-id="{{$information->id}}" style="cursor:pointer"></span>
                        @else
                        @endif
                    @endif
                </p>
            </div>
            <div class="col-xl-12" style="text-align:justify">
                <?php echo html_entity_decode($information->content); ?>
            </div>
            @if(count($information->files) > 0)
                <div class="col-xl-12 row mt-3">
                    <h4 class="col-12"><i class="fa  fa-paperclip"></i> Attachments</h4>
                    @foreach($information->files as $key=>$file)
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="{{url('/files/'.$file->name)}}" target="_blank"><b>{{$key + 1 }}</b>. {{$file->name}}</a>
                            @if(Auth::user()->role_id == 1)
                                @if($file->softDelete == 1)
                                    <span class="text-danger fa fa-times file-delete" data-id="{{$file->id}}" style="cursor:pointer"></span>
                                @else
                                @endif
                            @endif
                        </div>
                    @endforeach
                </div>
            @endif
            @if(count($information->photos) > 0)
                <div class="col-xl-12 row mt-3">
                    <h4 class="col-12"><i class="fa  fa-image"></i> Photo</h4>
                    @foreach($information->photos as $key=>$photo)
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="{{url('/photo/'.$photo->name)}}" target="_blank"><b>{{$key + 1 }}</b>. {{$photo->name}}</a>
                            <img src="{{ asset('photo/' . $photo->name) }}" class="img-fluid img-thumbnail" alt="Photo">
                        </div>
                            @if(Auth::user()->role_id == 1)
                                @if($photo->softDelete == 1)
                                    <span class="text-danger fa fa-times photo-delete" data-id="{{$photo->id}}" style="cursor:pointer"></span>
                                @else
                                @endif
                            @endif
                        </div>
                    @endforeach
                </div>
            @endif
            @if(count($information->movies) > 0)
                <div class="col-xl-12 row">
                    <h4 class="col-12"><i class="fa fa-video"></i> Movies</h4> 
                    @foreach($information->movies as $key=>$movie)
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="{{url('../resources/views/download.php?id='.$movie->name)}}"  data-id="{{$movie->name}}">{{$movie->name}}</a>
                            @if(Auth::user()->role_id == 1)
                                @if($movie->softDelete == 1)
                                    <span class="text-danger fa fa-times movie-delete"  data-id="{{$movie->id}}" style="cursor:pointer"></span>
                                @else
                                @endif
                            @endif
                        </div>
                    @endforeach     
                </div><!-- col-xl-12 -->
            @endif
        </div>
    </div>
@endsection
@section("script")
<script>
     var baseUrl = '{{url("")}}';
    $(document).ready(function(){
        $(document).on("click",".information-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/admin/admin-news/'+id+'/informationDelete',
                    type: "GET",
                    data: [],
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        console.log(JSON.stringify(response));
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.href= baseUrl+"/admin/notifications";
                        }
                    }
                });
            }
        });
        $(document).on("click",".file-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/admin/admin-news/'+id+'/fileDelete',
                    type: "GET",
                    data: [],
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".photo-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete ?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/admin/admin-news/'+id+'/photoDelete',
                    type: "GET",
                    data: {
                        "_token": "{{ csrf_token() }}",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".movie-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/admin/admin-news/'+id+'/movieDelete',
                    type: "GET",
                    data: [],
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        }); 
    });
</script>
@endsection