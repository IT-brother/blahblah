@extends('layouts.master')
@section('title','News list')
@section('header')
    <!--div class="col-7 align-self-center">
        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">News List</h4>
        <div class="d-flex align-items-center">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb m-0 p-0">
                    <li class="breadcrumb-item"><a href="index.html" class="text-muted">Apps</a></li>
                    <li class="breadcrumb-item text-muted active" aria-current="page">News List</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="col-5 align-self-center">
        <div class="customize-input float-right">
            <button class=" custom-select-set form-control bg-white border-0 custom-shadow custom-radius">
                CREATE NEW <i class="fa fa-plus text-success"></i>
            </button>
        </div>
    </div--->
    <?php
        use App\Http\Controllers\InformationController;
    ?>
    <div class="col-xl-12">
        <form class="row shadow">
            @csrf
            <div class="form-group col-md-6 col-lg-3 pb-0">
                <label for="title" class="control-label mt-0" style="margin:0px;padding:0;color:yellow;">Title<strong class="text-danger">*</strong></label>
                <input type="text" name="title" id="title" value="{{request()->title}}" autocomplete="off" class="mt-0 form-control">
            </div>
            <div class="form-group col-md-6 col-lg-3 pb-0">
                <label for="category" class="control-label mt-0" style="margin:0px;padding:0;color:yellow;">Category<strong class="text-danger">*</strong></label>
                <select name="category" id="category" autocomplete="off" class="form-control">
                    <option value=""></option>
                    @if(count($categories) > 0)
                        @foreach($categories as $category)
                            @if(request()->category == $category->id)
                                <option value="{{$category->id}}" selected>{{$category->name}}</option>
                            @else
                                <option value="{{$category->id}}">{{$category->name}}</option>
                            @endif
                        @endforeach
                    @endif
                </select>
            </div>
            <div class="form-group col-md-6 col-lg-3 m-0 pb-0">
                <label for="from" class="control-label mt-0" style="margin:0px;padding:0;color:yellow;">From<strong class="text-danger">*</strong></label>
                <input type="text" name="from" value="{{request()->from}}" id="from" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-3 m-0 pb-0">
                <label for="to" class="control-label mt-0" style="margin:0px;padding:0;color:yellow;">To<strong class="text-danger">*</strong></label>
                <input type="text" name="to" id="to" value="{{request()->to}}" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-3 mt-0 pt-0">
                <label for="content" class="control-label mt-0" style="margin:0px;padding:0;color:yellow;">Content<strong class="text-danger">*</strong></label>
                <input type="text" name="content" value="{{request()->content}}" id="content" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-3 mt-0 pt-0">
                <label for="user_id" class="control-label mt-0" style="margin:0px;padding:0;color:yellow;">Moderator<strong class="text-danger">*</strong></label>
                <select name="user_id" id="user_id" autocomplete="off" class="form-control">
                    <option value=""></option>
                    @if(count($users) > 0)
                        @foreach($users as $user)
                            @if(request()->user_id == $user->id)
                                <option value="{{$user->id}}" selected>{{$user->name}}</option>
                            @else
                                <option value="{{$user->id}}">{{$user->name}}</option>
                            @endif
                        @endforeach
                    @endif
                </select>
            </div>
            <div class="form-group col-md-6 col-lg-3 mt-0 pt-0">
                <label for="published" class="control-label mt-0" style="margin:0px;padding:0;color:yellow;">Published<strong class="text-danger">*</strong></label>
                <select name="published" id="published" autocomplete="off" class="form-control">
                    @if(request()->published == "" || request()->published == 1)
                        <option value="1" selected>Published</option>
                        <option value="0">Unpublished</option>    
                    @else
                        <option value="1">Published</option>
                        <option value="0" selected>Unpublished</option>
                    @endif
                </select>
            </div>
            <div class="form-group col-md-6 col-lg-3 mt-0 pt-0">
                <label for="" class="control-label mt-0">&nbsp;&nbsp;</label>
                <button type="submit" name="export" value="search" class="btn btn-primary mt-4">Search</button>
                <button type="submit" name="export" value="export" class="btn btn-success mt-4" id="excel-export">Export excel</button>
            </div>
        </form>
    </div>
@endsection
@section('content')
        <div class="col-xl-12 table-responsive p-0">
            <table id="zero_config" class="table table-striped table-bordered no-wrap">
                <thead>
                    <tr>
                        <th style="width:50px;max-width:50px;">#</th>
                        <th>Title</th>
                        <th style="min-width:200px;max-width:200px;">Category</th>
                        <th style="width:60px;max-width:60px;">Date</th>
                        <th style="width:120px;max-width:120px;font-weight:bold;">Moderator</th>
                        <th style="width:60px;max-width:60px;">Published</th>
                        <th style="width:100px;max-width:100px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                @if(count($informations) > 0)
                    @foreach($informations as $key=>$information)
                    @if($information->published == 1)
                        @php $published ="published"; @endphp
                    @else
                        @php $published = "unpublished"; @endphp
                    @endif
                    <tr>
                        <td>{{$key + 1}}</td>
                            <td>
                                <a href="{{url(Auth::user()->roles->name.'/moderator-news/'.$information->id)}}" style="color:#0099FF;text-decoration:underline;">
                                    {{ $information->title }}
                                </a>
                            </td>
                        <td>
                            <?php echo InformationController::category_convert($information->id); ?>
                        </td>
                        <td>{{date('d-m-Y',strtotime($information->date))}}</td>
                        <td>
                            <?php echo InformationController::moderator($information->user_id); ?>
                        </td>
                        <td>{{$published}}</td>
                        <td>
                            @if(Auth::user()->id == $information->user_id)
                                <a href="{{url(Auth::user()->roles->name.'/moderator-news/'.$information->id.'/edit')}}" class="btn btn-primary"><i class="fa fa-edit"></i> Edit</a>
                            @else
                        
                            @endif
                        </td>
                    </tr>
                    @endforeach
                @else
                    <tr>
                        <td colspan="7" style="text-align:center">There is no news...</td>
                    </tr>
                @endif
                </tbody>
            </table>
            {{$informations->links()}}
        </div>
@endsection
@section("script")
<script>
    $(document).ready(function(){
        // $("#category").select2();
        var from = new Pikaday(
        {
            field: document.getElementById('from'),
            theme: 'triangle-theme'
        });
        var to = new Pikaday(
        {
            field: document.getElementById('to'),
            theme: 'triangle-theme'
        });
        // $(document).on("click","#excel-export",function(){
        //     $.ajax({
        //             url:{{url("/export")}},
        //             type: "get",
        //             data:"",
        //             cache:false,
        //             contentType:false,
        //             processData:false,
        //             success: function(response)
        //             {
        //                 alert(response);
        //             }
        //     });
        // });
    });
</script>
@endsection