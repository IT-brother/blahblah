@extends('layouts.master')
@section('title','Moderator dashboard')
@section('header')
    <div class="col-7 align-self-center">
        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Dashboard</h4>
        <!-- <div class="d-flex align-items-center">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb m-0 p-0">
                    <li class="breadcrumb-item"><a href="index.html" class="text-muted">Apps</a></li>
                    <li class="breadcrumb-item text-muted active" aria-current="page">Dashboard</li>
                </ol>
            </nav>
        </div> -->
        {{Auth::user()->roles->name}}
    </div>
@endsection
@section('content')
    <div class="col-xl-12">Today Result</div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <!-- Column -->
                <div class="col-md-6 col-lg-3 col-xlg-3">
                    <div class="card card-hover">
                        <div class="p-2 bg-primary text-center">
                            <h1 class="font-light text-white">{{$today_informations}}</h1>
                            <h6 class="text-white"><i class="fa fa-th-list"></i> Total News</h6>
                        </div>
                    </div>
                </div>
                <!-- Column -->
                <div class="col-md-6 col-lg-3 col-xlg-3">
                    <div class="card card-hover">
                        <div class="p-2 bg-info text-center">
                            <h1 class="font-light text-white">{{$today_files}}</h1>
                            <h6 class="text-white"><i class="fa fa-file"></i> Document</h6>
                        </div>
                    </div>
                </div>
                <!-- Column -->
                <div class="col-md-6 col-lg-3 col-xlg-3">
                    <div class="card card-hover">
                        <div class="p-2 bg-success text-center">
                            <h1 class="font-light text-white">{{$today_photo}}</h1>
                            <h6 class="text-white"><i class="fa fa-image"></i> Photo</h6>
                        </div>
                    </div>
                </div>
                <!-- Column -->
                <div class="col-md-6 col-lg-3 col-xlg-3">
                    <div class="card card-hover">
                        <div class="p-2 bg-danger text-center">
                            <h1 class="font-light text-white">{{$today_videos}}</h1>
                            <h6 class="text-white"><i class="fa fa-video"></i> Movie</h6>
                        </div>
                    </div>
                </div>
            <!-- Column -->
            </div>
        </div>
    </div>
    <div class="col-xl-12">
        <form class="row shadow">
            @csrf
            <div class="form-group col-md-6 col-lg-3 pb-0">
                <label for="category" class="control-label" style="margin:0px;padding:0;">Category</label>
                <select name="category" id="category" autocomplete="off" class="form-control">
                    <option value=""></option>
                    @if(count($categoriess) > 0)
                        @foreach($categoriess as $categories)
                            @if(request()->category == $categories->id)
                                <option value="{{$categories->id}}" selected>{{$categories->name}}</option>
                            @else
                                <option value="{{$categories->id}}">{{$categories->name}}</option>
                            @endif
                        @endforeach
                    @endif
                </select>
            </div>
            <div class="form-group col-md-6 col-lg-3 m-0 pb-0">
                <label for="from" class="control-label" style="margin:0px;padding:0;">From</label>
                <input type="text" name="from" value="{{request()->from}}" id="from" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-3 m-0 pb-0">
                <label for="to" class="control-label" style="margin:0px;padding:0;">To</label>
                <input type="text" name="to" id="to" value="{{request()->to}}" autocomplete="off" class="form-control">
            </div>
            
            <div class="form-group col-md-6 col-lg-3 mt-3 pt-0">
                <button type="submit" name="search" value="dashboard" class="btn btn-primary mt-1">Search</button>
            </div>
        </form>
    </div>
    <div class="col-xl-12">All Result</div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <!-- Column -->
                <div class="col-md-6 col-lg-3 col-xlg-3">
                    <div class="card card-hover">
                        <div class="p-2 bg-primary text-center">
                            <h1 class="font-light text-white">{{$informations}}</h1>
                            <h6 class="text-white"><i class="fa fa-th-list"></i> Total News</h6>
                        </div>
                    </div>
                </div>
                <!-- Column -->
                <div class="col-md-6 col-lg-3 col-xlg-3">
                    <div class="card card-hover">
                        <div class="p-2 bg-info text-center">
                            <h1 class="font-light text-white">{{$files}}</h1>
                            <h6 class="text-white"><i class="fa fa-file"></i> Document</h6>
                        </div>
                    </div>
                </div>
                <!-- Column -->
                <div class="col-md-6 col-lg-3 col-xlg-3">
                    <div class="card card-hover">
                        <div class="p-2 bg-success text-center">
                            <h1 class="font-light text-white">{{$photo}}</h1>
                            <h6 class="text-white"><i class="fa fa-image"></i> Photo</h6>
                        </div>
                    </div>
                </div>
                <!-- Column -->
                <div class="col-md-6 col-lg-3 col-xlg-3">
                    <div class="card card-hover">
                        <div class="p-2 bg-danger text-center">
                            <h1 class="font-light text-white">{{$videos}}</h1>
                            <h6 class="text-white"><i class="fa fa-video"></i> Movie</h6>
                        </div>
                    </div>
                </div>
            <!-- Column -->
            </div>
        </div>
    </div>
@endsection
@section("script")
<script>
    var from = new Pikaday(
    {
        field: document.getElementById('from'),
        theme: 'triangle-theme'
    });
    var to = new Pikaday(
    {
        field: document.getElementById('to'),
        theme: 'triangle-theme'
    });
</script>
@endsection