@extends('layouts.master')
@section('title','Login log list')
@section('header')
    <div  class="col-xl-12">
        <form class="row shadow">
            <div class="form-group col-md-6 col-lg-2 pb-0">
                <label for="user_id" class="control-label" style="margin:0px;padding:0;">User</label>
                <select  name="user_id" id="user_id"  class="mt-0 form-control">
                    <option value=""></option>
                    @if(count($users) > 0)
                        @foreach($users as $key=>$user)
                            @if(request()->user_id == $user->id)
                                <option value="{{$user->id}}" selected>{{$user->name}}</option>
                            @else
                                <option value="{{$user->id}}">{{$user->name}}</option>
                            @endif
                        @endforeach
                    @endif
                </select>
            </div>
            <div class="form-group col-md-6 col-lg-2 m-0 pb-0">
                <label for="from" class="control-label" style="margin:0px;padding:0;">From</label>
                <input type="text" name="from" id="from" value="{{request()->from}}" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-2 m-0 pb-0">
                <label for="to" class="control-label" style="margin:0px;padding:0;">To</label>
                <input type="text" name="to" id="to" value="{{request()->to}}" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-4 mt-0 pt-0">
                <label for="" class="control-label mt-0">&nbsp;&nbsp;</label>
                <button type="submit" name="export" value="search" class="btn btn-primary mt-4"><i class="fa fa-search"></i> Search</button>
                <button type="submit" name="export" value="export" class="btn btn-success mt-4"><i class="fa fa-file-excel"></i> Export excel</button>
            </div>
        </form>
    </div>
@endsection
@section('content')
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="zero_config" class="table table-striped table-bordered no-wrap">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Start</th>
                        <th>End</th>
                    </tr>
                </thead>
                <tbody>
                    @if(count($loginlogs) > 0)
                        @foreach($loginlogs as $key=>$loginlog)
                            <tr>
                                <td>{{ $key + 1}}</td>
                                <td>{{$loginlog->users->name}}</td>
                                <td>{{$loginlog->created_at}}</td>
                                <td>{{$loginlog->updated_at}}</td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="4" style="text-align:center">There is no record...</td>
                        </tr>
                    @endif
                </tbody>
            </table>
            @if($loginlogs instanceof \Illuminate\Pagination\AbstractPaginator)
                {{$loginlogs->links()}}
            @endif
        </div>
    </div>
</div>
@endsection
@section('script')
<script>
    var from = new Pikaday(
        {
            field: document.getElementById('from'),
            theme: 'triangle-theme'
        });
    var to = new Pikaday(
        {
            field: document.getElementById('to'),
            theme: 'triangle-theme'
        });

</script>
@endsection