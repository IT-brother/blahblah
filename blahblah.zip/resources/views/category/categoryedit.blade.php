
@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center text-info">{{ __('Category Update') }}</div>
                <div class="card-body">
                    @if(session('status'))
                        <p class="alert alert-success">{{session('status')}}</p>
                    @endif
                    <form method="POST" >
                        @csrf
                        
                        <div class="form-group row ">
                            <label for="category_name" class="col-md-4 col-form-label text-md-right">{{ __('Category_Name') }}</label>

                            <div class="col-md-6">
                                <input id="category_name" type="text" class="form-control @error('category_name') is-invalid @enderror" name="category_name" value="{{$category[0]->name}}" required autocomplete="category_name" autofocus>

                                
                            </div>
                        </div>

                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-paper-plane"></i>
                                    {{ __('Edit') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
