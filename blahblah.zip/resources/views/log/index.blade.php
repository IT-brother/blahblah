@extends('layouts.master')
@section('title','Activity log')
@section('header')
    <div  class="col-xl-12">
        <form class="row shadow">
            @csrf
            <div class="form-group col-md-6 col-lg-2 m-0 pb-0">
                <label for="title" class="control-label" style="margin:0px;padding:0;">Title</label>
                <input type="text" name="title" value="{{request()->title}}" id="title" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-2 pb-0">
                <label for="user_id" class="control-label" style="margin:0px;padding:0;">User</label>
                <select  name="user_id" id="user_id"   class="mt-0 form-control">
                    <option value=""></option>
                    @if(count($users) > 0)
                        @foreach($users as $key=>$user)
                            @if($user->id == request()->user_id)
                                <option value="{{$user->id}}" selected>{{$user->name}}</option>
                            @else
                                <option value="{{$user->id}}">{{$user->name}}</option>
                            @endif
                        @endforeach
                    @endif
                </select>
            </div>
            <div class="form-group col-md-6 col-lg-2 m-0 pb-0">
                <label for="from" class="control-label" style="margin:0px;padding:0;">From</label>
                <input type="text" name="from" id="from" value="{{request()->from}}" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-2 m-0 pb-0">
                <label for="to" class="control-label" style="margin:0px;padding:0;">To</label>
                <input type="text" name="to" id="to" value="{{request()->to}}" autocomplete="off" class="form-control">
            </div>

            <div class="form-group col-md-6 col-lg-4 mt-0 pt-0">
                <label for="" class="control-label mt-0">&nbsp;&nbsp;</label>
                <button type="submit" name="export" value="search" class="btn btn-primary mt-4"><i class="fa fa-search"></i> Search</button>
                <button type="submit" name="export" value="export" class="btn btn-success mt-4"><i class="fa fa-file-excel"></i> Export excel</button>
            </div>
        </form>
    </div>
@endsection
@section('content')
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="zero_config" class="table table-striped table-bordered no-wrap">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Name</th>
                        <th>Date</th>
                        <th>Activity</th>
                    </tr>
                </thead>
                <tbody>
                    @if(count($logs) > 0)
                        @foreach($logs as $key=>$log)
                            <tr>
                                <td>{{ $key + 1}}</td>
                                <td>{{$log->title}}</td>
                                <td>{{$log->users->name}}</td>
                                <td>{{$log->created_at}}</td>
                                <td>{{$log->activity}}</td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="5" style="text-align:center">There is no activity...</td>
                        </tr>
                    @endif
                </tbody>
            </table>
            @if($logs instanceof \Illuminate\Pagination\AbstractPaginator)
                {{$logs->links()}}
            @endif
        </div>
    </div>
</div>
@endsection
@section('script')
<script>
    var from = new Pikaday(
        {
            field: document.getElementById('from'),
            theme: 'triangle-theme'
        });
    var to = new Pikaday(
        {
            field: document.getElementById('to'),
            theme: 'triangle-theme'
        });
</script>
@endsection