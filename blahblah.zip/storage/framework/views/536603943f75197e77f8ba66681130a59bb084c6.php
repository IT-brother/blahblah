
<?php $__env->startSection('title','News list'); ?>
<?php $__env->startSection('header'); ?>
    <!--div class="col-7 align-self-center">
        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">News List</h4>
        <div class="d-flex align-items-center">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb m-0 p-0">
                    <li class="breadcrumb-item"><a href="index.html" class="text-muted">Apps</a></li>
                    <li class="breadcrumb-item text-muted active" aria-current="page">News List</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="col-5 align-self-center">
        <div class="customize-input float-right">
            <button class=" custom-select-set form-control bg-white border-0 custom-shadow custom-radius">
                CREATE NEW <i class="fa fa-plus text-success"></i>
            </button>
        </div>
    </div--->
    <?php
        use App\Http\Controllers\InformationController;
    ?>
    <div class="col-xl-12">
        <form class="row shadow">
            <?php echo csrf_field(); ?>
            <div class="form-group col-md-6 col-lg-3 pb-0">
                <label for="title" class="control-label mt-0" style="margin:0px;padding:0;">Title</label>
                <input type="text" name="title" id="title" value="<?php echo e(request()->title); ?>" autocomplete="off" class="mt-0 form-control">
            </div>
            <div class="form-group col-md-6 col-lg-3 pb-0">
                <label for="category" class="control-label mt-0" style="margin:0px;padding:0;">Category</label>
                <select name="category" id="category" autocomplete="off" class="form-control">
                    <option value=""></option>
                    <?php if(count($categories) > 0): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(request()->category == $category->id): ?>
                                <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group col-md-6 col-lg-3 m-0 pb-0">
                <label for="from" class="control-label mt-0" style="margin:0px;padding:0;">From</label>
                <input type="text" name="from" value="<?php echo e(request()->from); ?>" id="from" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-3 m-0 pb-0">
                <label for="to" class="control-label mt-0" style="margin:0px;padding:0;">To</label>
                <input type="text" name="to" id="to" value="<?php echo e(request()->to); ?>" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-3 mt-0 pt-0">
                <label for="content" class="control-label mt-0" style="margin:0px;padding:0;">Content</label>
                <input type="text" name="content" value="<?php echo e(request()->content); ?>" id="content" autocomplete="off" class="form-control">
            </div>
            <div class="form-group col-md-6 col-lg-3 mt-0 pt-0">
                <label for="user_id" class="control-label mt-0" style="margin:0px;padding:0;">Moderator</label>
                <select name="user_id" id="user_id" autocomplete="off" class="form-control">
                    <option value=""></option>
                    <?php if(count($users) > 0): ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(request()->user_id == $user->id): ?>
                                <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group col-md-6 col-lg-3 mt-0 pt-0">
                <label for="published" class="control-label mt-0" style="margin:0px;padding:0;">Published</label>
                <select name="published" id="published" autocomplete="off" class="form-control">
                    <?php if(request()->published == "" || request()->published == 1): ?>
                        <option value="1" selected>Published</option>
                        <option value="0">Unpublished</option>    
                    <?php else: ?>
                        <option value="1">Published</option>
                        <option value="0" selected>Unpublished</option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group col-md-6 col-lg-3 mt-0 pt-0">
                <label for="" class="control-label mt-0">&nbsp;&nbsp;</label>
                <button type="submit" name="export" value="search" class="btn btn-primary mt-4">Search</button>
                <button type="submit" name="export" value="export" class="btn btn-success mt-4" id="excel-export">Export excel</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div class="col-xl-12 table-responsive p-0">
            <table id="zero_config" class="table table-striped table-bordered no-wrap">
                <thead>
                    <tr>
                        <th style="width:50px;max-width:50px;">#</th>
                        <th>Title</th>
                        <th style="min-width:200px;max-width:200px;">Category</th>
                        <th style="width:60px;max-width:60px;">Date</th>
                        <th style="width:120px;max-width:120px;font-weight:bold;">Moderator</th>
                        <th style="width:60px;max-width:60px;">Published</th>
                        <th style="width:100px;max-width:100px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(count($informations) > 0): ?>
                    <?php $__currentLoopData = $informations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($information->published == 1): ?>
                        <?php $published ="published"; ?>
                    <?php else: ?>
                        <?php $published = "unpublished"; ?>
                    <?php endif; ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><a href="<?php echo e(url(Auth::user()->roles->name.'/moderator-news/'.$information->id)); ?>" style="color:#0099FF;text-decoration:underline;"><?php echo html_entity_decode($information->title); ?></a></td>
                        <td>
                            <?php echo InformationController::category_convert($information->id); ?>
                        </td>
                        <td><?php echo e(date('d-m-Y',strtotime($information->date))); ?></td>
                        <td>
                            <?php echo InformationController::moderator($information->user_id); ?>
                        </td>
                        <td><?php echo e($published); ?></td>
                        <td>
                            <?php if(Auth::user()->id == $information->user_id): ?>
                                <a href="<?php echo e(url(Auth::user()->roles->name.'/moderator-news/'.$information->id.'/edit')); ?>" class="btn btn-primary"><i class="fa fa-edit"></i> Edit</a>
                            <?php else: ?>
                        
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align:center">There is no news...</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<script>
    $(document).ready(function(){
        // $("#category").select2();
        var from = new Pikaday(
        {
            field: document.getElementById('from'),
            theme: 'triangle-theme'
        });
        var to = new Pikaday(
        {
            field: document.getElementById('to'),
            theme: 'triangle-theme'
        });
        // $(document).on("click","#excel-export",function(){
        //     $.ajax({
        //             url:<?php echo e(url("/export")); ?>,
        //             type: "get",
        //             data:"",
        //             cache:false,
        //             contentType:false,
        //             processData:false,
        //             success: function(response)
        //             {
        //                 alert(response);
        //             }
        //     });
        // });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\htdocs\moi\resources\views/moderator/news.blade.php ENDPATH**/ ?>