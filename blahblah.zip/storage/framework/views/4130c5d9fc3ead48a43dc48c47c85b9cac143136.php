
<?php $__env->startSection('title','Show detail'); ?>
<?php $__env->startSection('header'); ?>
    <?php if(session('status')): ?>
        <div class="offset-lg-4 col-lg-4 alert alert-success p-2"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
    <style>
    /* Make the image fully responsive */
    .carousel-inner img {
        width: 100%;
        height: 100%;
    }
  </style>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body row">
            <div class="col-xl-12">
                <h3>
                    <?php echo html_entity_decode($information->title); ?>
                </h3>
                <p style="font-size:13px;">
                    <span class='badge badge-default border' style='font-size:13px;'>
                        <i class="fa fa-calendar text-success"></i>
                        <?php echo e(date('d-m-Y',strtotime($information->date))); ?>

                    </span>
                    <?php $__currentLoopData = $information->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class='badge badge-default border' style='font-size:13px;'><i class="fa fa-tag text-info"></i> <?php echo e($category->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($information->published == 1): ?>
                        <span class='badge badge-default border' style='font-size:13px;'><i class="fa fa-circle text-success"></i> Published</span>    
                    <?php else: ?>
                        <span class='badge badge-default border' style='font-size:13px;'><i class="fa fa-tag text-danger"></i> Unpublished</span>    
                    <?php endif; ?>
                    <span class='badge badge-default border' style='font-size:13px;'>
                        <i class="fa fa-user text-default"></i>
                        <?php echo e($information->users->name); ?>

                    </span>
                    
                </p>
            </div>
            <div class="col-xl-12" style="text-align:justify">
                <?php echo html_entity_decode($information->content); ?>
            </div>
            <?php if(count($information->files) > 0): ?>
                <div class="col-xl-12 row mt-3">
                    <h4 class="col-12"><i class="fa  fa-paperclip"></i> Attachments</h4>
                    <?php $__currentLoopData = $information->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="<?php echo e(url('/files/'.$file->name)); ?>" target="_blank"><b><?php echo e($key + 1); ?></b>. <?php echo e($file->name); ?></a> 
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(count($information->photos) > 0): ?>
                <div class="col-xl-12 row mt-3">
                    <h4 class="col-12"><i class="fa  fa-image"></i> Photo</h4>
                 
                    <?php $__currentLoopData = $information->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="<?php echo e(url('/photo/'.$photo->name)); ?>" target="_blank"><b><?php echo e($key + 1); ?></b>. <?php echo e($photo->name); ?></a>
                            <img src="<?php echo e(asset('photo/' . $photo->name)); ?>" class="img-fluid img-thumbnail" alt="Photo">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(count($information->movies) > 0): ?>
                <div class="col-xl-12 row">
                    <h4 class="col-12"><i class="fa fa-video"></i> Movies</h4> 
                    <?php $__currentLoopData = $information->movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="<?php echo e(url('../resources/views/download.php?id='.$movie->name)); ?>"  data-id="<?php echo e($movie->name); ?>"><?php echo e($movie->name); ?></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                </div><!-- col-xl-12 -->
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<script>
     var baseUrl = '<?php echo e(url("")); ?>';
    $(document).ready(function(){
        $(document).on("click",".information-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator-news/'+id+'/softDelete',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".information-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator-news/'+id+'/softDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".file-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator-news/'+id+'/fileSoftDelete',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".file-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator-news/'+id+'/fileSoftDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".photo-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator-news/'+id+'/photoSoftDelete',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".photo-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator-news/'+id+'/photoSoftDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".movie-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator-news/'+id+'/movieSoftDelete',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".movie-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator-news/'+id+'/movieSoftDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\htdocs\moi\resources\views/information/show.blade.php ENDPATH**/ ?>