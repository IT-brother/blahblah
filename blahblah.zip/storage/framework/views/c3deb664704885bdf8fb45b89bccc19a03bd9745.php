
<?php $__env->startSection('title','Edit news'); ?>
<?php $__env->startSection('header'); ?>
    <?php if(session('status')): ?>
        <div class="offset-lg-4 col-lg-4 alert alert-success p-2"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php if(session('errors')): ?>
    <div class="row col-xl-12 alert alert-success p-2 alert alert-warning">
       <ul> 
        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="card">
        <div class="card-body">
            <?php if($information->user_id == Auth::user()->id): ?>
                <?php if($information->softDelete == null): ?>
                    <span class="fa fa-times waves-effect waves-danger text-danger float-right information-delete" data-id="<?php echo e($information->id); ?>" style="cursor:pointer"></span>
                <?php else: ?>
                    <span class="fa fa-check waves-effect waves-danger text-success float-right information-cancel" data-id="<?php echo e($information->id); ?>" style="cursor:pointer;"></span>
                <?php endif; ?>
            <?php endif; ?>
            <div class="form-group">
                <label class="control-label" for="title">Title (ခေါင်းစဉ်)<b class="text-danger">*</b></label>
                <input type="text" value="<?php echo e($information->title); ?>" class="form-control" name="title" id="title">
            </div>
            <?php $__currentLoopData = $information->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectedCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $selectedArray[]=$selectedCategory->id; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group row">
                <div class="col-lg-6">
                    <label class="control-label"  for="category_id">Category (အမျိုးအစား)<b class="text-danger">*</b></label>
                    <select  class="form-control" name="category_id[]"  id="category_id" multiple>
                        <option value=""></option>
                        <?php if(count($categories) > 0): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(in_array($category->id,$selectedArray)): ?>
                                    <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-lg-6">
                    <label class="control-label" for="date">Date (ရက်စွဲ)<b class="text-danger">*</b></label>
                    <input type="text" value="<?php echo e($information->date); ?>" name="date" class="form-control" id="date">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label" for="content">Content (အချက်အလက်များ)<b class="text-danger">*</b></label>
                <textarea  name="content" id="content" class="summernote">
                    <?php echo html_entity_decode($information->content); ?>
                </textarea>
            </div>
            <?php if(count($information->files) > 0): ?>
                <div class="col-xl-12 row mt-3">
                    <h4 class="col-12"><i class="fa  fa-paperclip"></i> Attachments</h4>
                    <?php $__currentLoopData = $information->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="<?php echo e(url('/files/'.$file->name)); ?>" target="_blank"><b><?php echo e($key + 1); ?></b>. <?php echo e($file->name); ?></a>
                            <?php if($information->user_id == Auth::user()->id): ?>
                                <?php if($file->softDelete == null): ?>
                                    <span class="text-danger fa fa-times file-delete" data-id="<?php echo e($file->id); ?>" style="cursor:pointer;margin-left:5px;"></span>
                                <?php else: ?>
                                    <span class="text-success fa fa-check file-cancel" data-id="<?php echo e($file->id); ?>" style="cursor:pointer;margin-left:5px;"></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(count($information->photos) > 0): ?>
               <div class="col-xl-12 mt-2 row">
                    <h4 class="col-12"><i class="fa  fa-image"></i> Photo</h4>
                    <?php $__currentLoopData = $information->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 p-2"> 
                            <a href="<?php echo e(url('/photo/'.$photo->name)); ?>" target="_blank"><b><?php echo e($key + 1); ?></b>. <?php echo e($photo->name); ?></a>
                            <?php if($information->user_id == Auth::user()->id): ?>
                                <?php if($photo->softDelete == null): ?>
                                    <span class="text-danger fa fa-times photo-delete" data-id="<?php echo e($photo->id); ?>" style="cursor:pointer;margin-left:5px;"></span>
                                <?php else: ?>
                                    <span class="text-success fa fa-check photo-cancel" data-id="<?php echo e($photo->id); ?>" style="cursor:pointer;margin-left:5px;"></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(count($information->movies) > 0): ?>
                <div class="col-xl-12 mt-2 row">
                    <h4 class="col-12"><i class="fa fa-video"></i> Movies</h4> 
                    <?php $__currentLoopData = $information->movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4 p-2"> 
                        <a href="<?php echo e(url('../resources/views/download.php?id='.$movie->name)); ?>"  data-id="<?php echo e($movie->name); ?>"><?php echo e($movie->name); ?></a>
                        <?php if($information->user_id == Auth::user()->id): ?>
                            <?php if($movie->softDelete == null): ?>
                                <span class="text-danger fa fa-times movie-delete"  data-id="<?php echo e($movie->id); ?>" style="cursor:pointer;margin-left:5px;"></span>
                            <?php else: ?>
                                <span class="text-success fa fa-check movie-cancel" data-id="<?php echo e($movie->id); ?>" style="cursor:pointer;margin-left:5px;"></span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                </div><!-- col-xl-12 -->
            <?php endif; ?>
            <div class="form-group">
                <label class="control-label" for="movies">Movies (Optional)</label>
                <input type="file" class="form-control" name="movies[]" multiple id="movies">
            </div>
            <div class="form-group">
                <label class="control-label" for="photos">Photo (Optional)</label>
                <input type="file" class="form-control" name="photos[]" multiple id="photos">
            </div>
            <div class="form-group">
                <label class="control-label" for="files">File (Optional)</label>
                <input type="file" class="form-control" name="files[]" multiple id="files">
            </div>
            <div class="form-group">
                <label class="control-label" for="published">Publish or Unpublish (ထုတ်ဝေမည် (သို့) မထုတ်ဝေ)</label>
                <select  class="form-control" name="published" id="published">
                    <?php if($information->published == 1): ?>
                        <option value="1" selected>Published</option>
                        <option value="0">Unpublished</option>
                    <?php else: ?>
                        <option value="1">Published</option>
                        <option value="0" selected>Unpublished</option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Update</button>
            </div>
            
        </div><!--- card-body --->
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<script>
     var baseUrl = '<?php echo e(url("")); ?>';
    $(document).ready(function(){
        $("#category_id").select2();
        var date = new Pikaday(
        {
            field: document.getElementById('date'),
            theme: 'triangle-theme'
        });
        $('.summernote').summernote({
            height: 200,
            tabsize: 2,
            toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'clear','strikethrough']],
                    // ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['height', ['height']],
                    //['table',['table']]
                ]  
        });
        $(document).on("click",".information-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/softDelete',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".information-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/softDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".file-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/fileSoftDelete',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".file-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/fileSoftDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".photo-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/photoSoftDelete',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".photo-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/photoSoftDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".movie-delete",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to delete?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/movieSoftDelete',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
        $(document).on("click",".movie-cancel",function(){
            var id = $(this).data("id");
            var conf = confirm("Are  you sure want to cancel?");
            if(conf ==  true)
            {
                $.ajax({
                    url: baseUrl+'/moderator/moderator-news/'+id+'/movieSoftDeleteCancel',
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        },
                    cache:false,
                    processData:false,
                    contentType:false,
                    success:function(response)
                    {
                        if(response.status == true)
                        {
                            alert(response.msg);
                            window.location.reload();
                        }
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\htdocs\moi\resources\views/information/edit.blade.php ENDPATH**/ ?>