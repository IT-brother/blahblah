<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
class RoleSeeder extends Seeder
{
    private $userData = [];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $roles =array(
            array(
                'name'  =>'admin',
                'created_at' => now()->toDateTimeString(),
                'updated_at' => now()->toDateTimeString()
            ),
            array(
                'name' =>'moderator',
                'created_at' => now()->toDateTimeString(),
                'updated_at' => now()->toDateTimeString()
            ),
            array(
                'name' =>'superadmin',
                'created_at' => now()->toDateTimeString(),
                'updated_at' => now()->toDateTimeString()
            )
        );
        //$chunks = array_chunk($userData, 500);
        foreach ($roles as $role) {
            Role::insert($role);
        }  
    }
}
