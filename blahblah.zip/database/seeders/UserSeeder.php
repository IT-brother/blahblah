<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users =array(
            array(
                'name'  =>'admin',
                'role_id'  => 1,
                'phone'   => '094585',
                'username' =>'admin',
                'password' => Hash::make('password'),                
                'activation' => 1,
                'created_at' => now()->toDateTimeString(),
                'updated_at' => now()->toDateTimeString()
            ),
            array(
                'name'  =>'moderator',
                'role_id'  => 2,
                'phone'   => '094585',
                'username' =>'moderator',
                'password' => Hash::make('password'),                
                'activation' => 1,
                'created_at' => now()->toDateTimeString(),
                'updated_at' => now()->toDateTimeString()
            ),
            array(
                'name'  =>'superadmin',
                'role_id'  => 3,
                'phone'   => '094585',
                'username' =>'superadmin',
                'password' => Hash::make('password'),                
                'activation' => 1,
                'created_at' => now()->toDateTimeString(),
                'updated_at' => now()->toDateTimeString()
            ),
        );
        foreach ($users as $user) {
            User::insert($user);
        }  
    }
}
