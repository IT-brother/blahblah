<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use App\Models\Information;
class InformationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for($i=0;$i<=1000000;$i++)
        {
            $informations[]=[
                'title' => Str::random(50),
                'content' => Str::random(200),
                'user_id' => 2,
                'date'    =>'2021-05-25',
                'category_id' => 3,
                'softDelete'  => 1,
                'published'   => 1,
                'created_at' => now()->toDateTimeString(),
                'updated_at' => now()->toDateTimeString()
            ];
        }
        $chunks = array_chunk($informations, 500);
        foreach ($chunks as $chunk) {
            Information::insert($chunk);
        } 
    }
}
