<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('information', function (Blueprint $table) {
            $table->id();
            $table->text("title");
            $table->longText("content");
            $table->date("date");
           // $table->bigInteger("category_id")->unsigned();
            //$table->bigInteger("language_id")->unsigned();
            $table->bigInteger("user_id")->unsigned();
            //$table->bigInteger("localization_id")->unsigned();
            $table->integer("softDelete")->nullable();
            $table->integer("published");
            $table->bigInteger("artId")->unique();
            $table->text("resource");
            $table->timestamps();
           // $table->foreign('category_id')->references('id')->on('categories');
            //$table->foreign('language_id')->references('id')->on('languages');
            $table->foreign('user_id')->references('id')->on('users');
            //$table->foreign('localization_id')->references('id')->on('localizations');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('information');
    }
}
