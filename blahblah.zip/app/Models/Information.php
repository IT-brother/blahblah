<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Information extends Model
{
    use HasFactory;
    protected $fillable = ["title","content","date","user_id","published","softDelete"];
    public function information_category()
    {
        return $this->hasMany("App\Models\InformationCategory","information_id","id");
    }
    public function categories()
    {
        return $this->belongsToMany("App\Models\Category", 'information_categories', 'information_id', 'category_id');
    }
    public function users()
    {
        return $this->belongsTo("App\Models\User","user_id","id");
    }

    public function photos()
    {
        return $this->hasMany("App\Models\Photo","information_id","id");
    }
    public function files()
    {
        return $this->hasMany("App\Models\File","information_id","id");
    }
    public function movies()
    {
        return $this->hasMany("App\Models\Video","information_id","id");
    }
}
