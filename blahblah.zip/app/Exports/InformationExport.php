<?php

namespace App\Exports;
use Illuminate\Http\Request;

use App\Models\Information;
use Maatwebsite\Excel\Concerns\FromCollection;

class InformationExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Information::orderBy("id","desc")->take(20)->get();
       // return Information::all();
    }
}
