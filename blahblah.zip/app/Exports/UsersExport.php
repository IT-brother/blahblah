<?php

namespace App\Exports;

use App\Models\User;
use App\Models\Role;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMapping;

class UsersExport implements FromCollection,WithHeadingRow,WithMapping
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //return User::all();
        $result = User::join('roles', 'roles.id', '=', 'users.role_id')
                ->select('users.*')
                ->get();
       /* $exportUser = User::all();

        return $array = $exportUser->map(function ($b, $key) {

            return [
                'id' => $b->id,
                'name' =>$b->name,
                "role_id" => $b->roles->name,
                'phone' =>$b->phone,
                'username' =>$b->username,
                'activation'=>$b->activation,
            'created_at' => $b->created_at,
            'updated_at' => $b->updated_at ] 
        });
        */
    }
}
