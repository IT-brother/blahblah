<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\Category;
use App\Models\User;
class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //today result
        $today_informations = number_format(
            DB::table("information")
            ->where("information.user_id","=",Auth::user()->id)
            ->whereDate("information.created_at",Carbon::today())
            ->count()
        );
        $today_files = number_format(
            DB::table("files")
            ->leftJoin("information","information.id","=","files.information_id")
            ->where("information.user_id","=",Auth::user()->id)
            ->whereDate("files.created_at",Carbon::today())
            ->count()
        );
        $today_photo = number_format(
            DB::table("photos")
            ->leftJoin("information","information.id","=","photos.information_id")
            ->where("information.user_id","=",Auth::user()->id)
            ->whereDate("photos.created_at",Carbon::today())
            ->count()
        );
        $today_videos = number_format(
            DB::table("videos")
            ->leftJoin("information","information.id","=","videos.information_id")
            ->where("information.user_id","=",Auth::user()->id)
            ->whereDate("videos.created_at",Carbon::today())
            ->count()
        );
        $categoriess = Category::all();
        //all result
        //filtering query
        $category_id = $request->get("category");
        $from = date("Y-m-d",strtotime($request->get("from")));
        $to = date("Y-m-d",strtotime($request->get("to")));
        $informations= DB::table("view_information");
        $files = DB::table("view_files");
        $photo = DB::table("view_photos");
        $videos = DB::table("view_videos");
        if($request->get("from") !="" && $request->get("to") !="")
        {
            $informations->whereBetween("date",[$from,$to]);
            $files->whereBetween("created_at",[$from,$to]);
            $photo->whereBetween("created_at",[$from,$to]);
            $videos->whereBetween("created_at",[$from,$to]);
        }     
        if($category_id !="")
        {
            $informations->where("category_id",$category_id);
            $files->where("category_id",$category_id);
            $photo->where("category_id",$category_id);
            $videos->where("category_id",$category_id);
        }
        //for login user
        $informations->where("user_id",Auth::user()->id);
        $files->where("user_id",Auth::user()->id);
        $photo->where("user_id",Auth::user()->id);
        $videos->where("user_id",Auth::user()->id);
        
        $informations= $informations->distinct("id")->count();
        $files= $files->distinct("name")->count();
        $photo = $photo->distinct("name")->count();
        $videos= $videos->distinct("name")->count();
        return view("moderator.dashboard",compact("informations","files","photo","videos"
                    ,"today_informations","today_files","today_photo","today_videos",
                    "categoriess"));
    }
    public function admin_dashboard(Request $request)
    {
        //today result 
        $today_informations = number_format(
            DB::table("information")->whereDate("created_at",Carbon::today())->count()
        );
        $today_files = number_format(
            DB::table("files")
            ->whereDate("files.created_at",Carbon::today())
            ->count()
        );
        $today_photo = number_format(
            DB::table("photos")
            ->whereDate("photos.created_at",Carbon::today())
            ->count()
        );
        $today_videos = number_format(
            DB::table("videos")
            ->whereDate("videos.created_at",Carbon::today())
            ->count()
        );
        //constant data
        $category = number_format(
            DB::table("categories")->count()
        );
        $user_total = number_format(
            DB::table("users")->count()
        );
        $categoriess = Category::all();
        $userss = User::where("role_id",2)->get();
        //all result
        //filtering  request
        //is user search?
        if(count($request->all()) > 0)
        {
            $category_id = $request->get("category");
            $user_id = $request->get("user_id");
            $from = date("Y-m-d",strtotime($request->get("from")));
            $to = date("Y-m-d",strtotime($request->get("to")));
            $informations= DB::table("view_information");
            $files = DB::table("view_files");
            $photo = DB::table("view_photos");
            $videos = DB::table("view_videos");
            if($request->get("from") !="" && $request->get("to") !="")
            {
                $informations->whereBetween("date",[$from,$to]);
                $files->whereBetween("created_at",[$from,$to]);
                $photo->whereBetween("created_at",[$from,$to]);
                $videos->whereBetween("created_at",[$from,$to]);
            }     
            if($category_id !="")
            {
                $informations->where("category_id",$category_id);
                $files->where("category_id",$category_id);
                $photo->where("category_id",$category_id);
                $videos->where("category_id",$category_id);
            }
            if($user_id !="")
            {
                $informations->where("user_id",$user_id);
                $files->where("user_id",$user_id);
                $photo->where("user_id",$user_id);
                $videos->where("user_id",$user_id);
            }
            $informations= $informations->distinct("id")->count();
            $files= $files->distinct("name")->count();
            $photo = $photo->distinct("name")->count();
            $videos= $videos->distinct("name")->count();
        }else
        {
            $informations = number_format(
                DB::table("information")->count()
            );
            $files = number_format(
                DB::table("files")
                ->count()
            );
            $photo = number_format(
                DB::table("photos")
                ->count()
            );
            $videos = number_format(
                DB::table("videos")
                ->count()
            );
        }
        return view("admin.dashboard",compact("informations","files","photo","videos",
        "category","user_total","today_informations","today_files","today_photo","today_videos",
        "categoriess","userss"
        ));
    }

    // Change password****************

    public function view_changepassword(){
        $roles = number_format(
            DB::table("roles")->count()
        );
        $users = number_format(
            DB::table("users")
            ->leftJoin("roles","roles.id","=","users.role_id")
            ->count()
        );
        return view("auth.passwords.change",compact("users","roles"));
    }

    public function admin_changepassword(Request $changepass){
        $changepass->validate([
            'current_password' => ['required', new MatchOldPassword],
            'new_password' => ['required'],
            'new_confirm_password' => ['same:new_password'],
        ]);
   
        User::find(auth()->user()->id)->update(['password'=> Hash::make($changepass->new_password)]);
   
        dd('Password change successfully.');

    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
