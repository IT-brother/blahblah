<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use App\Models\Category;
use App\Models\Information;
use App\Models\Video;
use App\Models\Photo;
use App\Models\File;
use App\Models\User;
use App\Models\Log;
use App\Models\LoginLog;
use App\Models\InformationCategory;
use Illuminate\Support\Facades\DB;
use Storage;
class InformationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */ 
    public function index(Request $request)
    {
        $informations = DB::table("view_information")
        ->select("id","title","content","date","published","user_id");
        $categories = Category::all();
        $users = User::where("role_id",2)->get();
        $collectArray = array();
        if(!empty($request->get("from") && !empty($request->get("to"))))
        {
            $from = date('Y-m-d',strtotime($request->get("from")));
            $to   = date('Y-m-d',strtotime($request->get("to")));
            $collectArray[] = $from;
            $collectArray[]=$informations->whereBetween("date",[$from,$to]);
        }
        if(!empty($request->get("title")))
        {
            $title = $request->get("title").'%';
            $collectArray[] = $title;
            $collectArray[]=$informations->where("title","LIKE",$title);
        }
        if($request->get("category") !="")
        {
            $category = (int) $request->get("category");
            $collectArray[] = $category;
            $collectArray[]=$informations->where("category_id","=",$category);
        }
        if($request->get("user_id") !="")
        {
            $user_id =  (int) $request->get("user_id");
            $collectArray[] = $user_id;
            $collectArray[]=$informations->where("user_id","=",$user_id);
        }
        if($request->get("content") !="")
        {
            $content = '%'.$request->get("content").'%';
            $collectArray[] = $content;
            $collectArray[]=$informations->where("content","LIKE",$content);
        }
        if($request->get("published") !="")
        {
             $published = (int) $request->get("published");
             $collectArray[] = $published;
             $informations->where("published","=",$published);
        }
        if($request->get("export") == "export")
        {
            $informations = $informations->distinct()->get();
            $this->export2Excel($informations);//export excel 
        }else //$request->get("export ) is export 
        {
            if(count($collectArray) > 0)
            {
                $informations = $informations->distinct()->paginate(10);
                $informations = $informations->appends($request->all()); 
            }else
            {
                $informations = $informations->distinct()->limit(12)->paginate();
            }
            return view("moderator.news",compact("informations","categories","users"));
        }
    }
    public function export2Excel($informations)
    {
        $table = "<table border='1'>";
        $table .='<thead>
                    <tr>
                        <th style="width:50px;max-width:50px;font-weight:bold;">Sr</th>
                        <th style="font-weight:bold;">Title</th>
                        <th style="min-width:300px;max-width:300px;font-weight:bold;">Category</th>
                        <th style="width:60px;max-width:60px;font-weight:bold;">Date</th>
                        <th style="width:150px;max-width:150px;font-weight:bold;">Moderator</th>
                    </tr>
                 </thead>';
        if(count($informations) > 0){
            foreach($informations as $key=>$information)
            {
                $date = date('d-m-Y',strtotime($information->date));
                $categories = $this->category_convert($information->id);
                $moderator = $this->moderator($information->user_id);
                $table.="<tr>";
                    $table.="<td style='padding:7px;border:1px solid #000;'>".($key + 1)."</td>";
                    $table.="<td style='padding:7px;border:1px solid #000;width:500px;'>".$information->title."</td>";
                    $table.="<td style='padding:7px;border:1px solid #000;width:300px;'>".$categories."</td>";
                    $table.="<td style='padding:7px;border:1px solid #000;width:120px;'>".$date."</td>";
                    $table.="<td style='padding:7px;border:1px solid #000;width:150px;'>".$moderator."</td>";
                $table.="</tr>";
            }
        } 
        $table.="</table>";  
        header('Content-Type: application/vnd.ms-excel');  
        header('Content-disposition: attachment; filename='.rand().'.xls');  
        echo $table;
    }
    public static function moderator($user_id)
    {
        $moderator = User::find($user_id)->select("name")->where("id","=",$user_id)->get();
        return $moderator[0]->name;
    }
    public static  function category_convert($information_id)
    {
        $categories = DB::table("information_categories")
                    ->join("categories","categories.id","=","information_categories.category_id")
                    ->select("categories.name as category_name")
                    ->where("information_id","=",$information_id)
                    ->get();
        $name ="";
        foreach($categories as $key=>$category)
        {
            if($key == 0)
            {
                $name.=$category->category_name;
            }else
            {
                $name.=" ၊ ".$category->category_name;
            }
        }
        return $name;           
    }


    public function admin_news(Request $request)
    {
        //return $request->all();
        //$informations = Information::orderBy("id","desc")->take(10)->get();
        $categories = Category::all();
        $users = User::where("role_id",2)->get();
        $informations = DB::table("view_information")->select("id","title","content","date","published","user_id");
        $collectArray = array();
        if(!empty($request->get("from") && !empty($request->get("to"))))
        {
            $from = date('Y-m-d',strtotime($request->get("from")));
            $to   = date('Y-m-d',strtotime($request->get("to")));
            $collectArray[] = $from;
            $collectArray[]=$informations->whereBetween("date",[$from,$to]);
        }
        if(!empty($request->get("title")))
        {
            $title = $request->get("title").'%';
            $collectArray[] = $title;
            $collectArray[]=$informations->where("title","LIKE",$title);
        }
        if($request->get("category") !="")
        {
            $category = (int) $request->get("category");
            $collectArray[] = $category;
            $collectArray[]=$informations->where("category_id","=",$category);
        }
        if($request->get("user_id") !="")
        {
            $user_id =  (int) $request->get("user_id");
            $collectArray[] = $user_id;
            $collectArray[]=$informations->where("user_id","=",$user_id);
        }
        if($request->get("content") !="")
        {
            $content = '%'.$request->get("content").'%';
            $collectArray[] = $content;
            $collectArray[]=$informations->where("content","LIKE",$content);
        }
        if($request->get("published") !="")
        {
             $published = (int) $request->get("published");
             $collectArray[] = $published;
             $informations->where("published","=",$published);
        }
        if($request->get("export") == "export")
        {
            $informations = $informations->distinct()->get();
            $this->export2Excel($informations);//export excel 
        }else //$request->get("export ) is export 
        {
            
            if(count($collectArray) > 0)
            {
                $informations = $informations->distinct()->paginate(10);
                $informations = $informations->appends($request->all()); 
            }else
            {
                $informations = $informations->distinct()->limit(12)->paginate();
            }
            return view("admin.admin-news",compact("informations","categories","users"));
        }       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        return view("information.create",compact("categories"));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       // return $request->all();
        //return $request["movies"];
        $validate = Validator::make($request->only(
            'title', 'content', 'date', 'category_id'), 
            [
            'title'     => 'required',
            'content'   => 'required',
            'date'      => 'required',
            'category_id'      => 'required',
        ]);
        if($validate->fails()) {
            return redirect("/upload")->with("errors",$validate->messages()->all());
        }else{
            $inserted_id = Information::create([
                'title'           => $request["title"],
                'content'   => $request["content"],
                'date'      => date('Y-m-d',strtotime($request["date"])),
                //'category_id'=> $request["category_id"],
                'user_id'  => Auth::user()->id,
                'published' => 1,
                'softDelete' => NULL,
            ])->id;
       // return $request["category_id"];
            if(isset($request["category_id"]))
            {
                if(count($request->get("category_id")) > 0)
                {
                    foreach($request->get("category_id") as $category)
                    {
                        $information_category = InformationCategory::create([
                                "information_id" => $inserted_id,
                                "category_id"    => $category,
                        ]);
                    }
                }
            }
            if(isset($request["movies"]))
            {
                if(count($request["movies"]) > 0)
                {
                    foreach($request["movies"] as $key=>$movie)
                    {
                        $moviename=date('d-m-Y',strtotime($request["date"]))."_".uniqid().".".$movie->extension();
                        $movie->move(public_path().'/videos/',$moviename);
                        $video = Video::create([
                            "name" => $moviename,
                            "information_id" => $inserted_id,
                        ]);
                    }
                }
            }
            if(isset($request["photos"]))
            {
                if(count($request["photos"]) > 0)
                {
                    foreach($request["photos"] as $key=>$photo)
                    {
                        $photoname=date('d-m-Y',strtotime($request["date"]))."_".uniqid().".".$photo->extension();
                        $photo->move(public_path().'/photo/',$photoname);
                        $photo = Photo::create([
                            "name" => $photoname,
                            "information_id" => $inserted_id,
                        ]);
                    }
                }
            }
            if(isset($request["files"]))
            {
                if(count($request["files"]) > 0)
                {
                    foreach($request["files"] as $key=>$file)
                    {
                        $filename=date('d-m-Y',strtotime($request["date"]))."_".uniqid().".".$file->extension();
                        $file->move(public_path().'/files/',$filename);
                        $file = File::create([
                            "name" => $filename,
                            "information_id" => $inserted_id,
                        ]);
                    }
                }
            }
            return redirect("/moderator/upload")->with("status","Successfully added news");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $information = Information::find($id);
        return view("information.show",compact("information"));   
    }
    //admin
    public function admin_show($id)
    {
        $information = Information::find($id);
        return view("information.adminshow",compact("information"));   
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categories = Category::all();
        $information = Information::find($id);
        return view("information.edit",compact("information","categories"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validate = Validator::make($request->only(
            'title', 'content', 'date', 'category_id'), 
            [
            'title'     => 'required',
            'content'   => 'required',
            'date'      => 'required',
            'category_id'      => 'required',
        ]);
        if($validate->fails()){
            return redirect(Auth::user()->roles->name."/moderator-news/".$id."/edit")->with("errors",$validate->messages()->all());
        }else{
            $information = Information::find($id);
            $information->title = $request["title"];
            $information->content = $request["content"];
            $information->date     = date('Y-m-d',strtotime($request["date"]));
            $information->published  =$request["published"];
            $information->update();
            $information->categories()->sync($request["category_id"]);
            //log insert
            Log::create([
                "user_id" => Auth::user()->id,
                "information_id" => $id,
                "activity"  => "အချက်အလက်ပြင်ဆင်သည်"
            ]);
            //insert new
            if(isset($request["movies"]))
            {
                if(count($request["movies"]) > 0)
                {
                    foreach($request["movies"] as $key=>$movie)
                    {
                        $moviename=date('d-m-Y',strtotime($request["date"]))."_".uniqid().".".$movie->extension();
                        $movie->move(public_path().'/videos/',$moviename);
                        $video = Video::create([
                            "name" => $moviename,
                            "information_id" => $id,
                        ]);
                    }
                }
            }
            if(isset($request["photos"]))
            {
                if(count($request["photos"]) > 0)
                {
                    foreach($request["photos"] as $key=>$photo)
                    {
                        $photoname=date('d-m-Y',strtotime($request["date"]))."_".uniqid().".".$photo->extension();
                        $photo->move(public_path().'/photo/',$photoname);
                        $photo = Photo::create([
                            "name" => $photoname,
                            "information_id" => $id,
                        ]);
                    }
                }
            }
            if(isset($request["files"]))
            {
                if(count($request["files"]) > 0)
                {
                    foreach($request["files"] as $key=>$file)
                    {
                        $filename=date('d-m-Y',strtotime($request["date"]))."_".uniqid().".".$file->extension();
                        $file->move(public_path().'/files/',$filename);
                        $file = File::create([
                            "name" => $filename,
                            "information_id" => $id,
                        ]);
                    }
                }
            }
            return redirect(Auth::user()->roles->name."/moderator-news/".$id."/edit")->with("status","Successfully updated");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    // public function download($id)
    // {
    //     $url = "/videos/".$id;
    //     header('Content-Description: File Transfer');
    //     header('Content-Type: application/octet-stream');
    //     header('Content-Disposition: attachment; filename="'.basename($url).'"');
    //     header('Expires: 0');
    //     header('Cache-Control: must-revalidate');
    //     header('Pragma: public');
    //     header('Content-Length: ' . filesize($url));
    //     flush(); // Flush system output buffer
    //     readfile($url);
    // }
    public function notifications()
    {
        $informations = Information::where("softDelete",1)->get();
        $photos = Photo::where("softDelete",1)->get();
        $videos = Video::where("softDelete",1)->get();
        $files  = File::where("softDelete",1)->get();
        return view("information.notifications",compact("informations","photos","videos","files"));
    }
    public function informationSoftDelete($information_id)
    {
        $information = Information::find($information_id);
        $information->softDelete = 1;
        $information->update();
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully requested to admin"
        ]);
    }
    public function informationSoftDeleteCancel($information_id)
    {
        $information = Information::find($information_id);
        $information->softDelete = NULL;
        $information->update();
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully canceled"
        ]);
    }
    public function fileSoftDelete($file_id)
    {
        $file = File::find($file_id);
        $file->softDelete = 1;
        $file->update();
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully requested to admin"
        ]);
    }
    public function fileSoftDeleteCancel($file_id)
    {
        $file = File::find($file_id);
        $file->softDelete = NULL;
        $file->update();
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully canceled"
        ]);
    }
    public function photoSoftDelete($photo_id)
    {
        $photo = Photo::find($photo_id);
        $photo->softDelete = 1;
        $photo->update();
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully requested to admin"
        ]);
    }
    public function photoSoftDeleteCancel($photo_id)
    {
        $photo = Photo::find($photo_id);
        $photo->softDelete = NULL;
        $photo->update();
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully canceled"
        ]);
    }
    public function movieSoftDelete($video_id)
    {
        $video = Video::find($video_id);
        $video->softDelete = 1;
        $video->update();
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully requested to admin"
        ]);
    }
    public function movieSoftDeleteCancel($video_id)
    {
        $video = Video::find($video_id);
        $video->softDelete = NULL;
        $video->update();
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully canceled"
        ]);
    }
    
    public function informationDelete($information_id)
    {
        $information = Information::find($information_id);
        if(count($information->files) > 0 )
        {
            foreach($information->files as $key=>$file)
            {
               $path = public_path()."/files/$file->name";
               if(file_exists($path))
               {
                @unlink($path);
               } 
               $file->delete(); 
            }
        }
        if(count($information->movies) > 0 )
        {
            foreach($information->movies as $key=>$movie)
            {
               $path = public_path()."/videos/$movie->name";
               if(file_exists($path))
               {
                    @unlink($path);
               } 
               $movie->delete();
            }
        }
        if(count($information->photos) > 0 )
        {
            foreach($information->photos as $key=>$photo)
            {
               $path = public_path()."/photo/$photo->name";
               if(file_exists($path))
               {
                    @unlink($path);
               } 
               $photo->delete();
            }
        }
        Log::where("information_id",$information_id)->delete();
        InformationCategory::where("information_id",$information_id)->delete();
        Information::destroy($information_id);
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully deleted"
        ]);
    }
    public function fileDelete($file_id)
    {
        $users=Auth::user()->id;
        $get_fileId=File::find($file_id)->select("information_id")
        ->where("id","=", $file_id)
        ->get();/**/
       
        foreach($get_fileId as $getfile)
        {
            Log::create([
                    "user_id" => $users,
                    "information_id" =>$getfile->information_id,
                    "activity"  => "Fileတစ်ခုခုအား ဖျက်ခဲ့သည်"
                    ]);
        }/**/

        $file = File::find($file_id);
        $path = public_path()."/files/$file->name";
        if(file_exists($path))
        {
            @unlink($path);
        } 
        $file->delete(); 
      
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully deleted file"
        ]);

        
        
    }

    public function photoDelete($photo_id)
    {
           
        $users=Auth::user()->id;
        $get_infoId=Photo::find($photo_id)->select("information_id")
        ->where("id","=", $photo_id)
        ->get();/**/
       
        foreach($get_infoId as $getting)
        {
            Log::create([
                    "user_id" => $users,
                    "information_id" =>$getting->information_id,
                    "activity"  => "Photoတစ်ခုခုအား ဖျက်ခဲ့သည်"
                    ]);
        }/**/

        $get_photoName= Photo::find($photo_id)->select("name")->where("id","=",$photo_id)->get();
        $photo= Photo::find($photo_id);
        $path= public_path()."/photo/$get_photoName";
       if(file_exists($path))
        {
            @unlink($path);
        } 
           
            
            $photo->delete();   
           
            return response()->json([
                "status"  => true,
                "msg"     => "Successfully deleted photo"
            ]);

    }

    //-----------------------Testing by Ypp--------------------------

    public function ypp($id){
        $users=Auth::user()->id;
        $get_infoId=Photo::find($id)->select("information_id")
        ->where("id","=", $id)
        ->get();/**/
       
        foreach($get_infoId as $getting)
        {
            Log::create([
                    "user_id" => $users,
                    "information_id" =>$getting->information_id,
                    "activity"  => "အချက်အလက်အား ဖျက်ခဲ့သည်"
                    ]);
        }/**/
    }
    //--------------------------------------------------

    public function movieDelete($video_id)
    {
        $users=Auth::user()->id;
        $get_videoId=Video::find($video_id)->select("information_id")
        ->where("id","=", $video_id)
        ->get();/**/
       
        foreach($get_videoId as $getvideo)
        {
            Log::create([
                    "user_id" => $users,
                    "information_id" =>$getvideo->information_id,
                    "activity"  => "movieတစ်ခုခုအား ဖျက်ခဲ့သည်"
                    ]);
        }/**/
        $video = Video::find($video_id);
        $path = public_path()."/videos/$video->name";
        if(file_exists($path))
        {
            @unlink($path);
        } 
        $video->delete(); 
        return response()->json([
            "status"  => true,
            "msg"     => "Successfully deleted video"
        ]);
    }
    /*
    api section
    */
    public function news_api(){
        $response = Http::get('https://www.moi.gov.mm/news-api?api_key=qGzCWJ7QYegKOOeG7O_Ebw', [
            'limit' => 10,
        ]);
        $news = json_decode($response->body());
        $count=0;
        foreach($news as $getNews)
        {
            $artIdCount = Information::where("artId",$getNews->artId)->count();
            if($artIdCount  < 1)
            {
                $inserted_id = Information::create([
                    'title'     => html_entity_decode($getNews->title),
                    'content'   => $getNews->content,
                    'date'      => date('Y-m-d H:i:s',strtotime($getNews->createDate)),
                    'user_id'  => Auth::user()->id,
                    'published' => 1,
                    'softDelete' => NULL,
                    'artId'      => $getNews->artId,
                    'resource'   => $getNews->resource
                ])->id;
                $information_category = InformationCategory::create([
                    "information_id" => $inserted_id,
                    "category_id"    => 5,
                ]);
                $count++;
            }
        }
		return redirect("/news-api")->with("status","Successfully inserted".$count." rows");
    }

    public function announce_api(){
        $response = Http::get('https://www.moi.gov.mm/announcement-api?api_key=qGzCWJ7QYegKOOeG7O_Ebw', [
            'limit' => 10,
        ]);
        $announce = json_decode($response->body());
        $count=0;
        foreach($announce as $getAnnounce)
        {
            $artIdCount = Information::where("artId",$getAnnounce->artId)->count();
            if($artIdCount  < 1)
            {
                $inserted_id = Information::create([
                    'title'     => html_entity_decode($getAnnounce->title),
                    'content'   => $getAnnounce->content,
                    'date'      => date('Y-m-d H:i:s',strtotime($getAnnounce->createDate)),
                    'user_id'  => Auth::user()->id,
                    'published' => 1,
                    'softDelete' => NULL,
                    'artId'      => $getAnnounce->artId,
                    'resource'   => $getAnnounce->resource
                ]);
                $information_category = InformationCategory::create([
                    "information_id" => $inserted_id,
                    "category_id"    => 5,
                ]);
                $count++;
            }
        }
		return redirect("/announce-api")->with("status","Successfully inserted".$count." rows");
    }
}
