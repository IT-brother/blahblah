<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('auth.login');
});
Route::group(array("prefix"=>"admin","middleware" => "Admin"),function(){
    Route::get("admin-dashboard",[App\Http\Controllers\DashboardController::class,'admin_dashboard']);
    Route::get("/admin-news",[App\Http\Controllers\InformationController::class,'admin_news']); 
    Route::get("/admin-news/{information_id}",[App\Http\Controllers\InformationController::class,'admin_show']);
    Route::get("notifications",[App\Http\Controllers\InformationController::class,'notifications'])->name("notifications");
    Route::get("admin-news/{information_id}/informationDelete",[App\Http\Controllers\InformationController::class,'informationDelete']);
    Route::get("/admin-news/{file_id}/fileDelete",[App\Http\Controllers\InformationController::class,'fileDelete']);
    Route::get("/admin-news/{photo_id}/photoDelete",[App\Http\Controllers\InformationController::class,'photoDelete']);
    Route::get("/admin-news/{video_id}/movieDelete",[App\Http\Controllers\InformationController::class,'movieDelete']);
    //admin user
    Route::get("/users",[App\Http\Controllers\UserController::class,'index']);
    Route::post("/users",[App\Http\Controllers\UserController::class,'store']);
    Route::get('users/{id}',[App\Http\Controllers\UserController::class, 'user_edit']);
    Route::post('users/{id}',[App\Http\Controllers\UserController::class, 'user_update']);
    Route::get('users/delete/{id}',[App\Http\Controllers\UserController::class, 'user_delete']);
    //common
    Route::get("/categories",[App\Http\Controllers\CategoryController::class,'index']);
    Route::post("/categories",[App\Http\Controllers\CategoryController::class,'store']);
    Route::get("/categories/{id}",[App\Http\Controllers\CategoryController::class, 'category_edit']);
    Route::post("/categories/{id}",[App\Http\Controllers\CategoryController::class, 'category_update']);
    Route::get("/categories/delete/{id}",[App\Http\Controllers\CategoryController::class, 'category_delete']);
    Route::get("/loginlog",[App\Http\Controllers\LoginLogController::class,'index']);
    Route::get("/activities",[App\Http\Controllers\LogController::class,'index']);
    Route::get("/moderator-news/{information_id}/edit",[App\Http\Controllers\InformationController::class,'edit']);
    Route::post("/moderator-news/{information_id}/edit",[App\Http\Controllers\InformationController::class,'update']);
    Route::get('/alluserExport',[App\Http\Controllers\UserController::class, 'alluserExport']);
//for testing by ypp
   // Route::get('/insertact/{id}',[App\Http\Controllers\InformationController::class, 'ypp']);
   //Get_api route
   Route::get('/news-api',[App\Http\Controllers\InformationController::class, 'news_api']);
   Route::get('/announce-api',[App\Http\Controllers\InformationController::class, 'announce_api']);
});

Route::group(array("prefix"=>"superadmin","middleware" => "Superadmin"),function(){
    //super admin 
    Route::get("admin-dashboard",[App\Http\Controllers\DashboardController::class,'admin_dashboard']);
    Route::get("/admin-news",[App\Http\Controllers\InformationController::class,'admin_news']); 
    Route::get("/admin-news/{information_id}",[App\Http\Controllers\InformationController::class,'admin_show']);
    Route::get("/moderators",[App\Http\Controllers\UserController::class,'moderatorsIndex']);
    Route::post("/moderators",[App\Http\Controllers\UserController::class,'moderatorsStore']);
    Route::get('moderators/{id}',[App\Http\Controllers\UserController::class, 'moderatorsEdit']);
    Route::post('moderators/{id}',[App\Http\Controllers\UserController::class, 'moderatorsUpdate']);
    Route::get('moderators/delete/{id}',[App\Http\Controllers\UserController::class, 'moderatorsDelete']);
    //common
    Route::get("/categories",[App\Http\Controllers\CategoryController::class,'index']);
    Route::post("/categories",[App\Http\Controllers\CategoryController::class,'store']);
    Route::get("/categories/{id}",[App\Http\Controllers\CategoryController::class, 'category_edit']);
    Route::post("/categories/{id}",[App\Http\Controllers\CategoryController::class, 'category_update']);
    Route::get("/categories/delete/{id}",[App\Http\Controllers\CategoryController::class, 'category_delete']);
    Route::get("/loginlog",[App\Http\Controllers\LoginLogController::class,'index']);
    Route::get("/activities",[App\Http\Controllers\LogController::class,'index']);
    Route::get("/moderator-news/{information_id}/edit",[App\Http\Controllers\InformationController::class,'edit']);
    Route::post("/moderator-news/{information_id}/edit",[App\Http\Controllers\InformationController::class,'update']);
    Route::get('/allmoderatorExport',[App\Http\Controllers\UserController::class, 'allmoderatorExport']);
    //Get_api route
    Route::get('/news-api',[App\Http\Controllers\InformationController::class, 'news_api']);
    Route::get('/announce-api',[App\Http\Controllers\InformationController::class, 'announce_api']);
});

Route::group(["prefix"=>"moderator","middleware" => "Moderator"],function(){
    Route::get("/dashboard",[App\Http\Controllers\DashboardController::class,'index']);
    Route::get("/upload",[App\Http\Controllers\InformationController::class,'create']);
    Route::post("/upload",[App\Http\Controllers\InformationController::class,'store']);
    Route::get("/moderator-news",[App\Http\Controllers\InformationController::class,'index']);
    Route::get("/moderator-news/{information_id}",[App\Http\Controllers\InformationController::class,'show']);
    Route::get("/moderator-news/{information_id}/edit",[App\Http\Controllers\InformationController::class,'edit']);
    Route::post("/moderator-news/{information_id}/edit",[App\Http\Controllers\InformationController::class,'update']);
    Route::get("/moderator-news/{information_id}/softDelete",[App\Http\Controllers\InformationController::class,'informationSoftDelete']);
    Route::get("/moderator-news/{information_id}/softDeleteCancel",[App\Http\Controllers\InformationController::class,'informationSoftDeleteCancel']);
    Route::get("/moderator-news/{file_id}/fileSoftDelete",[App\Http\Controllers\InformationController::class,'fileSoftDelete']);
    Route::get("/moderator-news/{file_id}/fileSoftDeleteCancel",[App\Http\Controllers\InformationController::class,'fileSoftDeleteCancel']);
    Route::get("/moderator-news/{photo_id}/photoSoftDelete",[App\Http\Controllers\InformationController::class,'photoSoftDelete']);
    Route::get("/moderator-news/{photo_id}/photoSoftDeleteCancel",[App\Http\Controllers\InformationController::class,'photoSoftDeleteCancel']);
    Route::get("/moderator-news/{photo_id}/movieSoftDelete",[App\Http\Controllers\InformationController::class,'movieSoftDelete']);
    Route::get("/moderator-news/{photo_id}/movieSoftDeleteCancel",[App\Http\Controllers\InformationController::class,'movieSoftDeleteCancel']);
    //Get_api route
    Route::get('/news-api',[App\Http\Controllers\InformationController::class, 'news_api']);
    Route::get('/announce-api',[App\Http\Controllers\InformationController::class, 'announce_api']);
});

Route::get("/admin-changepassword",[App\Http\Controllers\DashboardController::class,'view_changepassword']);
Route::post("/admin-changepassword",[App\Http\Controllers\DashboardController::class,'admin_changepassword']);
Route::get("/logout",[App\Http\Controllers\Auth\LoginController::class,'logout']);
Auth::routes();
 Route::get('/importExportView', [App\Http\Controllers\MyController::class, 'importExportView']);
 Route::post('/import',[App\Http\Controllers\MyController::class, 'import']);

//Route::get("/diagnoses/{filename}",[App\Http\Controllers\InformationController::class,'download']);